function updateTime(){


}